    package br.com.up.whats;

    import androidx.appcompat.app.AppCompatActivity;

    import android.content.Intent;
    import android.net.Uri;
    import android.os.Bundle;
    import android.view.View;
    import android.widget.Button;
    import android.widget.Toast;

    import com.google.android.material.textfield.TextInputEditText;
    import com.google.android.material.textfield.TextInputLayout;

    public class MainActivity extends AppCompatActivity {
        private TextInputLayout numInputLayout;
        private TextInputLayout messageInputLayout;
        private Uri webpage;

        private TextInputEditText numInputEditText;
        private TextInputEditText messageInputEditText;

        private Button sendButton;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            sendButton = findViewById(R.id.send_button);

            numInputLayout = findViewById(R.id.input_layout_number);
            numInputEditText = findViewById(R.id.input_text_number);

            messageInputLayout = findViewById(R.id.input_layout_message);
            messageInputEditText = findViewById(R.id.input_text_message);

            sendButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String phone = numInputEditText.getText().toString();
                    String message = messageInputEditText.getText().toString();
                    if (!message.isEmpty() && !phone.isEmpty()) {

                        Uri webpage = Uri.parse("https://wa.me/" + phone + "?text=" + message);

                        Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);

                        startActivity(webIntent);
                    } else {
                        Toast.makeText(MainActivity.this, "Por favor, informe o número de telefone e a mensagem", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

    }