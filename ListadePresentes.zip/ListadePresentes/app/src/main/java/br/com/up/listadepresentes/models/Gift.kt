package br.com.up.listadepresentes.models

data class Gift(
        var name:String,
        var giftName:String,
        var description:String
)
